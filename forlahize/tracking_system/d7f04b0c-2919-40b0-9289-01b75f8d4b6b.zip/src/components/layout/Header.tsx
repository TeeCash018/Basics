import React from 'react';
import { Bell, Search, Menu, Sun, Moon } from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { useTheme } from '../../contexts/ThemeContext';
export function Header() {
  const location = useLocation();
  const { theme, toggleTheme } = useTheme();
  const getPageTitle = () => {
    if (location.pathname.startsWith('/dashboard')) return 'Timesheet Overview';
    if (location.pathname.startsWith('/drivers/')) return 'Driver Details';
    if (location.pathname.startsWith('/drivers')) return 'Driver Management';
    if (location.pathname.startsWith('/attendance')) return 'Attendance Log';
    if (location.pathname.startsWith('/timestamps'))
    return 'Location Timestamps';
    if (location.pathname.startsWith('/tracking')) return 'Live Tracking';
    if (location.pathname.startsWith('/face-logs')) return 'Face Verification';
    if (location.pathname.startsWith('/settings')) return 'Settings';
    return 'TimeTrack';
  };
  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between px-6 flex-shrink-0 z-10 transition-colors">
      <div className="flex items-center">
        <button className="md:hidden mr-4 text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
          <Menu className="w-5 h-5" />
        </button>
        <h1 className="text-xl font-semibold text-slate-900 dark:text-white">
          {getPageTitle()}
        </h1>

        <div className="hidden md:flex items-center ml-6 px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-emerald-500/20 rounded-full">
          <div className="w-2 h-2 rounded-full bg-fleet-active mr-2 animate-pulse"></div>
          <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400 tabular-nums">
            Live • 8 drivers active
          </span>
        </div>
      </div>

      <div className="flex items-center space-x-4">
        <div className="relative hidden md:block">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search..."
            className="pl-9 pr-4 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-fleet-accent/50 focus:border-fleet-accent dark:text-white transition-all w-48 lg:w-64" />
          
        </div>

        <button
          onClick={toggleTheme}
          className="p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors"
          aria-label="Toggle theme">
          
          {theme === 'dark' ?
          <Sun className="w-5 h-5" /> :

          <Moon className="w-5 h-5" />
          }
        </button>

        <button className="relative p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-fleet-alert rounded-full border-2 border-white dark:border-slate-900"></span>
        </button>

        <div className="h-8 w-px bg-slate-200 dark:bg-slate-800 mx-2"></div>

        <div className="flex items-center cursor-pointer hover:opacity-80 transition-opacity">
          <div className="text-right mr-3 hidden sm:block">
            <div className="text-sm font-medium text-slate-900 dark:text-white">
              Alex Morgan
            </div>
            <div className="text-xs text-slate-500 dark:text-slate-400">
              Ops Manager
            </div>
          </div>
          <img
            src="https://i.pravatar.cc/150?img=68"
            alt="Ops Manager"
            className="w-9 h-9 rounded-full border border-slate-200 dark:border-slate-700 object-cover" />
          
        </div>
      </div>
    </header>);

}
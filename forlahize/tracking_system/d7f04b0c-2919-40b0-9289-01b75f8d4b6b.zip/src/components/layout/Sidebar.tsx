import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  ClipboardCheck,
  Clock,
  MapPin,
  ScanFace,
  Users,
  Settings,
  Truck } from
'lucide-react';
import { motion } from 'framer-motion';
const navItems = [
{
  path: '/dashboard',
  label: 'Dashboard',
  icon: LayoutDashboard
},
{
  path: '/attendance',
  label: 'Attendance',
  icon: ClipboardCheck
},
{
  path: '/timestamps',
  label: 'Timestamps',
  icon: Clock
},
{
  path: '/tracking',
  label: 'Live Tracking',
  icon: MapPin
},
{
  path: '/face-logs',
  label: 'Face Verification',
  icon: ScanFace
},
{
  path: '/drivers',
  label: 'Drivers',
  icon: Users
},
{
  path: '/settings',
  label: 'Settings',
  icon: Settings
}];

export function Sidebar() {
  return (
    <aside className="w-64 bg-fleet-sidebar text-slate-300 flex flex-col h-screen flex-shrink-0 border-r border-slate-800">
      <div className="h-16 flex items-center px-6 border-b border-slate-800">
        <Truck className="w-6 h-6 text-fleet-accent mr-3" />
        <span className="text-white font-semibold text-lg tracking-wide">
          TimeTrack
        </span>
      </div>

      <nav className="flex-1 py-6 px-3 space-y-1 overflow-y-auto">
        {navItems.map((item) =>
        <NavLink
          key={item.path}
          to={item.path}
          className={({ isActive }) =>
          `relative flex items-center px-3 py-2.5 rounded-md transition-colors group ${isActive ? 'text-white bg-fleet-sidebarHover' : 'hover:text-white hover:bg-slate-800/50'}`
          }>
          
            {({ isActive }) =>
          <>
                {isActive &&
            <motion.div
              layoutId="sidebar-active-indicator"
              className="absolute left-0 top-0 bottom-0 w-1 bg-fleet-accent rounded-r-full"
              initial={false}
              transition={{
                type: 'spring',
                stiffness: 300,
                damping: 30
              }} />

            }
                <item.icon
              className={`w-5 h-5 mr-3 ${isActive ? 'text-fleet-accent' : 'text-slate-400 group-hover:text-slate-300'}`} />
            
                <span className="font-medium text-sm">{item.label}</span>
              </>
          }
          </NavLink>
        )}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="bg-slate-800/50 rounded-lg p-3">
          <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold mb-2">
            System Status
          </div>
          <div className="flex items-center text-sm">
            <div className="w-2 h-2 rounded-full bg-fleet-active mr-2 animate-pulse"></div>
            <span className="text-slate-300">All systems operational</span>
          </div>
        </div>
      </div>
    </aside>);

}
import React from 'react';
import { Outlet } from 'react-router-dom';
import { Sidebar } from './Sidebar';
import { Header } from './Header';
import { Toaster } from 'sonner';
export function AppLayout() {
  return (
    <div className="flex h-screen w-full bg-fleet-bg dark:bg-slate-950 overflow-hidden transition-colors">
      <Sidebar />
      <div className="flex flex-col flex-1 min-w-0">
        <Header />
        <main className="flex-1 overflow-hidden relative">
          <Outlet />
        </main>
      </div>
      <Toaster position="top-right" richColors theme="system" />
    </div>);

}
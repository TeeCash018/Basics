import React, { useState } from 'react';
import { Driver } from '../../types';
import { DriverCard } from './DriverCard';
import { motion } from 'framer-motion';
interface DriverRosterProps {
  drivers: Driver[];
  selectedDriverId: string | null;
  onSelectDriver: (id: string) => void;
  alertsByDriver: Record<string, boolean>;
}
type FilterType = 'all' | 'active' | 'idle' | 'alert' | 'offline';
export function DriverRoster({
  drivers,
  selectedDriverId,
  onSelectDriver,
  alertsByDriver
}: DriverRosterProps) {
  const [filter, setFilter] = useState<FilterType>('all');
  const filteredDrivers = drivers.filter((d) => {
    if (filter === 'all') return true;
    return d.status === filter;
  });
  const filters: {
    id: FilterType;
    label: string;
  }[] = [
  {
    id: 'all',
    label: 'All'
  },
  {
    id: 'active',
    label: 'Active'
  },
  {
    id: 'idle',
    label: 'Idle'
  },
  {
    id: 'alert',
    label: 'Alerts'
  },
  {
    id: 'offline',
    label: 'Offline'
  }];

  return (
    <div className="flex flex-col h-full bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 w-full md:w-[360px] flex-shrink-0 transition-colors">
      <div className="p-4 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-slate-900 dark:text-white">
            Fleet Roster
          </h2>
          <span className="text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-full tabular-nums">
            {drivers.length} Total
          </span>
        </div>

        <div className="flex space-x-1 overflow-x-auto hide-scrollbar pb-1">
          {filters.map((f) =>
          <button
            key={f.id}
            onClick={() => setFilter(f.id)}
            className={`px-3 py-1.5 text-xs font-medium rounded-full whitespace-nowrap transition-colors ${filter === f.id ? 'bg-slate-800 dark:bg-slate-700 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'}`}>
            
              {f.label}
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-3 bg-slate-50/50 dark:bg-slate-950/50">
        {filteredDrivers.length === 0 ?
        <div className="text-center py-8 text-slate-500 dark:text-slate-400 text-sm">
            No drivers match this filter.
          </div> :

        filteredDrivers.map((driver, i) =>
        <motion.div
          key={driver.id}
          initial={{
            opacity: 0,
            y: 10
          }}
          animate={{
            opacity: 1,
            y: 0
          }}
          transition={{
            delay: i * 0.05,
            duration: 0.2
          }}>
          
              <DriverCard
            driver={driver}
            isSelected={selectedDriverId === driver.id}
            onClick={() => onSelectDriver(driver.id)}
            hasAlert={alertsByDriver[driver.id]} />
          
            </motion.div>
        )
        }
      </div>
    </div>);

}
import React from 'react';
import { BoxIcon } from 'lucide-react';
interface StatCardProps {
  title: string;
  value: string | number;
  icon: BoxIcon;
  trend?: {
    value: string;
    isPositive: boolean;
  };
  colorClass?: string;
}
export function StatCard({
  title,
  value,
  icon: Icon,
  trend,
  colorClass = 'text-fleet-accent bg-amber-50 dark:bg-amber-500/10 dark:text-amber-400'
}: StatCardProps) {
  return (
    <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm flex items-start justify-between transition-colors">
      <div>
        <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-1">
          {title}
        </h3>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-bold text-slate-900 dark:text-white tabular-nums">
            {value}
          </span>
          {trend &&
          <span
            className={`text-xs font-medium tabular-nums ${trend.isPositive ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
            
              {trend.isPositive ? '↑' : '↓'} {trend.value}
            </span>
          }
        </div>
      </div>
      <div className={`p-2 rounded-md ${colorClass}`}>
        <Icon className="w-5 h-5" />
      </div>
    </div>);

}
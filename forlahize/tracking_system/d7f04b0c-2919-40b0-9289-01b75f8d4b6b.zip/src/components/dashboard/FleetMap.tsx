import React, { useEffect, Fragment } from 'react';
import {
  MapContainer,
  TileLayer,
  Marker,
  Popup,
  useMap,
  Polyline } from
'react-leaflet';
import { divIcon } from 'leaflet';
import { Driver } from '../../types';
import { useNavigate } from 'react-router-dom';
import { ExternalLink } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
interface FleetMapProps {
  drivers: Driver[];
  selectedDriverId: string | null;
  alertsByDriver: Record<string, boolean>;
  showRoutes?: boolean;
}
function MapController({
  selectedDriver,
  drivers



}: {selectedDriver: Driver | null;drivers: Driver[];}) {
  const map = useMap();
  useEffect(() => {
    if (selectedDriver) {
      map.flyTo(
        [selectedDriver.location.lat, selectedDriver.location.lng],
        14,
        {
          duration: 1.5
        }
      );
    } else if (drivers.length > 0) {
      const bounds = drivers.map(
        (d) => [d.location.lat, d.location.lng] as [number, number]
      );
      if (bounds.length > 0) {
        map.fitBounds(bounds, {
          padding: [50, 50]
        });
      }
    }
  }, [selectedDriver, map, drivers]);
  return null;
}
export function FleetMap({
  drivers,
  selectedDriverId,
  alertsByDriver,
  showRoutes = false
}: FleetMapProps) {
  const navigate = useNavigate();
  const { theme } = useTheme();
  const selectedDriver = drivers.find((d) => d.id === selectedDriverId) || null;
  const createDriverIcon = (
  driver: Driver,
  isSelected: boolean,
  hasAlert: boolean) =>
  {
    const statusColors = {
      active: '#10b981',
      idle: '#f59e0b',
      alert: '#ef4444',
      offline: '#94a3b8'
    };
    const color = statusColors[driver.status];
    const size = isSelected ? 48 : 36;
    const html = `
      <div class="relative flex items-center justify-center transition-all duration-300" style="width: ${size}px; height: ${size}px;">
        <div class="absolute inset-0 rounded-full" style="background-color: ${color}; padding: 3px;">
          <img src="${driver.photoUrl}" class="w-full h-full rounded-full object-cover bg-white" />
        </div>
        <div class="absolute -bottom-1 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[8px]" style="border-top-color: ${color};"></div>
      </div>
    `;
    return divIcon({
      html,
      className: 'custom-driver-marker',
      iconSize: [size, size + 8],
      iconAnchor: [size / 2, size + 8],
      popupAnchor: [0, -(size + 8)]
    });
  };
  const center: [number, number] = [30.2672, -97.7431];
  // Use dark tiles for dark mode, light tiles for light mode
  const tileUrl =
  theme === 'dark' ?
  'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png' :
  'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
  return (
    <div className="w-full h-full relative z-0">
      <MapContainer
        center={center}
        zoom={12}
        className="w-full h-full"
        zoomControl={false}>
        
        <TileLayer
          attribution='&copy; <a href="https://carto.com/">Carto</a>'
          url={tileUrl} />
        

        <MapController selectedDriver={selectedDriver} drivers={drivers} />

        {drivers.map((driver) =>
        <Fragment key={driver.id}>
            {(showRoutes || selectedDriverId === driver.id) &&
          driver.route.length > 0 &&
          <Polyline
            positions={driver.route.map((p) => [p.lat, p.lng])}
            color={driver.status === 'alert' ? '#ef4444' : '#10b981'}
            weight={4}
            opacity={0.6}
            dashArray={driver.status === 'idle' ? '5, 10' : undefined} />

          }

            <Marker
            position={[driver.location.lat, driver.location.lng]}
            icon={createDriverIcon(
              driver,
              selectedDriverId === driver.id,
              alertsByDriver[driver.id] || false
            )}
            zIndexOffset={selectedDriverId === driver.id ? 1000 : 0}>
            
              <Popup className="driver-popup">
                <div className="p-1 min-w-[200px] text-slate-900">
                  <div className="flex items-center space-x-3 mb-3">
                    <img
                    src={driver.photoUrl}
                    alt=""
                    className="w-10 h-10 rounded-full" />
                  
                    <div>
                      <h4 className="font-semibold text-slate-900 m-0 leading-tight">
                        {driver.name}
                      </h4>
                      <span className="text-xs text-slate-500">
                        {driver.vehicleId}
                      </span>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mb-3 text-sm">
                    <div className="bg-slate-50 p-2 rounded">
                      <div className="text-xs text-slate-500 mb-0.5">Speed</div>
                      <div className="font-medium tabular-nums">
                        {driver.currentSpeed} mph
                      </div>
                    </div>
                    <div className="bg-slate-50 p-2 rounded">
                      <div className="text-xs text-slate-500 mb-0.5">
                        Heading
                      </div>
                      <div className="font-medium tabular-nums">
                        {driver.location.heading}°
                      </div>
                    </div>
                  </div>
                  <button
                  onClick={() => navigate(`/drivers/${driver.id}`)}
                  className="w-full py-2 bg-slate-900 text-white text-sm font-medium rounded-md hover:bg-slate-800 transition-colors flex items-center justify-center">
                  
                    View Details
                    <ExternalLink className="w-3.5 h-3.5 ml-1.5" />
                  </button>
                </div>
              </Popup>
            </Marker>
          </Fragment>
        )}
      </MapContainer>

      <div className="absolute top-4 right-4 z-[400] flex flex-col space-y-2 pointer-events-none">
        <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-sm p-2 rounded-md shadow-md border border-slate-200 dark:border-slate-800 pointer-events-auto">
          <div className="text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-2 px-1">
            Legend
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center text-xs text-slate-700 dark:text-slate-300">
              <div className="w-2.5 h-2.5 rounded-full bg-fleet-active mr-2"></div>{' '}
              Active
            </div>
            <div className="flex items-center text-xs text-slate-700 dark:text-slate-300">
              <div className="w-2.5 h-2.5 rounded-full bg-fleet-idle mr-2"></div>{' '}
              Idle
            </div>
            <div className="flex items-center text-xs text-slate-700 dark:text-slate-300">
              <div className="w-2.5 h-2.5 rounded-full bg-fleet-offline mr-2"></div>{' '}
              Offline
            </div>
          </div>
        </div>
      </div>
    </div>);

}
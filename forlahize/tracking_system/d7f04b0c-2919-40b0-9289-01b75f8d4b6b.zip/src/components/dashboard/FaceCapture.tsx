import React from 'react';
import { FaceCapture as FaceCaptureType } from '../../types';
import { MapPin, CheckCircle2, Clock } from 'lucide-react';
interface FaceCaptureProps {
  capture: FaceCaptureType;
}
export function FaceCapture({ capture }: FaceCaptureProps) {
  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  return (
    <div className="bg-white border border-slate-200 rounded-lg overflow-hidden flex flex-col shadow-sm">
      <div className="relative h-48 bg-slate-100">
        <img
          src={capture.photoUrl}
          alt="Driver face capture"
          className="w-full h-full object-cover" />
        
        {capture.verified &&
        <div className="absolute top-2 right-2 bg-emerald-500 text-white text-xs font-medium px-2 py-1 rounded-md flex items-center shadow-sm">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Verified
          </div>
        }
      </div>
      <div className="p-3 space-y-2">
        <div className="flex items-start">
          <MapPin className="w-4 h-4 text-slate-400 mr-1.5 mt-0.5 flex-shrink-0" />
          <span className="text-sm text-slate-700 line-clamp-2">
            {capture.location.address}
          </span>
        </div>
        <div className="flex items-center text-slate-500">
          <Clock className="w-4 h-4 mr-1.5" />
          <span className="text-xs tabular-nums">
            {formatTime(capture.timestamp)}
          </span>
        </div>
      </div>
    </div>);

}
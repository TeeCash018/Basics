import React from 'react';
import { Driver } from '../../types';
import { AlertTriangle, Clock, Gauge } from 'lucide-react';
interface DriverCardProps {
  driver: Driver;
  isSelected?: boolean;
  onClick?: () => void;
  hasAlert?: boolean;
}
const statusColors = {
  active: 'bg-fleet-active',
  idle: 'bg-fleet-idle',
  alert: 'bg-fleet-alert',
  offline: 'bg-fleet-offline'
};
const statusLabels = {
  active: 'On Route',
  idle: 'Idle',
  alert: 'Alert',
  offline: 'Offline'
};
export function DriverCard({
  driver,
  isSelected,
  onClick,
  hasAlert
}: DriverCardProps) {
  const formatTime = (isoString: string) => {
    const date = new Date(isoString);
    return date.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  return (
    <div
      onClick={onClick}
      className={`relative p-4 bg-white dark:bg-slate-900 border rounded-lg cursor-pointer transition-all duration-200 group
        ${isSelected ? 'border-fleet-accent shadow-md ring-1 ring-fleet-accent/20 dark:border-fleet-accent dark:ring-fleet-accent/30' : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 hover:shadow-sm'}
      `}>
      
      {hasAlert &&
      <div className="absolute -top-2 -right-2 z-10 flex items-center bg-fleet-alert text-white text-xs font-bold px-2 py-0.5 rounded-full shadow-sm">
          <AlertTriangle className="w-3 h-3 mr-1" />
          <span>!</span>
        </div>
      }

      <div className="flex items-start space-x-3">
        <div className="relative">
          <img
            src={driver.photoUrl}
            alt={driver.name}
            className="w-12 h-12 rounded-full object-cover border border-slate-200 dark:border-slate-700" />
          
          <div
            className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-white dark:border-slate-900 ${statusColors[driver.status]}`}>
          </div>
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex justify-between items-start mb-0.5">
            <h4 className="text-sm font-semibold text-slate-900 dark:text-white truncate">
              {driver.name}
            </h4>
            <span className="text-xs font-medium text-slate-500 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded">
              {driver.vehicleId}
            </span>
          </div>

          <div className="text-xs text-slate-500 dark:text-slate-400 mb-2">
            {statusLabels[driver.status]}
          </div>

          <div className="flex items-center space-x-3 text-xs text-slate-600 dark:text-slate-400">
            <div className="flex items-center">
              <Gauge className="w-3.5 h-3.5 mr-1 text-slate-400" />
              <span className="tabular-nums font-medium">
                {driver.currentSpeed}{' '}
                <span className="text-slate-400 dark:text-slate-500 font-normal">
                  mph
                </span>
              </span>
            </div>
            <div className="flex items-center">
              <Clock className="w-3.5 h-3.5 mr-1 text-slate-400" />
              <span className="tabular-nums">
                {formatTime(driver.lastSeen)}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>);

}
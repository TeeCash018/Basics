import React from 'react';
interface SliderProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
  step?: number;
  label?: string;
  unit?: string;
}
export function Slider({
  value,
  onChange,
  min = 0,
  max = 100,
  step = 1,
  label,
  unit = '%'
}: SliderProps) {
  return (
    <div className="w-full">
      {label &&
      <div className="flex justify-between items-center mb-2">
          <label className="text-sm font-medium text-slate-900 dark:text-slate-100">
            {label}
          </label>
          <span className="text-sm font-bold text-fleet-accent tabular-nums">
            {value}
            {unit}
          </span>
        </div>
      }
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-2 bg-slate-200 dark:bg-slate-700 rounded-lg appearance-none cursor-pointer accent-fleet-accent" />
      
      <div className="flex justify-between text-xs text-slate-400 mt-1 tabular-nums">
        <span>
          {min}
          {unit}
        </span>
        <span>
          {max}
          {unit}
        </span>
      </div>
    </div>);

}
import React from 'react';
interface ToggleProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: string;
  description?: string;
}
export function Toggle({ checked, onChange, label, description }: ToggleProps) {
  return (
    <div className="flex items-center justify-between">
      {(label || description) &&
      <div className="pr-4">
          {label &&
        <div className="text-sm font-medium text-slate-900 dark:text-slate-100">
              {label}
            </div>
        }
          {description &&
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {description}
            </div>
        }
        </div>
      }
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-fleet-accent focus:ring-offset-2 dark:focus:ring-offset-slate-900 ${checked ? 'bg-fleet-accent' : 'bg-slate-200 dark:bg-slate-700'}`}>
        
        <span
          aria-hidden="true"
          className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${checked ? 'translate-x-5' : 'translate-x-0'}`} />
        
      </button>
    </div>);

}
import React, { useState } from 'react';
import { Modal } from '../ui/Modal';
import {
  Camera,
  Upload,
  CheckCircle2,
  ScanFace,
  ChevronRight,
  ChevronLeft } from
'lucide-react';
import { toast } from 'sonner';
interface AddDriverModalProps {
  isOpen: boolean;
  onClose: () => void;
}
export function AddDriverModal({ isOpen, onClose }: AddDriverModalProps) {
  const [step, setStep] = useState(1);
  const [isScanning, setIsScanning] = useState(false);
  const [scanComplete, setScanComplete] = useState(false);
  const handleNext = () => setStep((s) => Math.min(s + 1, 3));
  const handleBack = () => setStep((s) => Math.max(s - 1, 1));
  const handleSave = () => {
    toast.success('Driver added successfully', {
      description: 'The new driver has been registered in the system.'
    });
    setTimeout(() => {
      setStep(1);
      setScanComplete(false);
      onClose();
    }, 500);
  };
  const simulateScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
      setScanComplete(true);
    }, 2000);
  };
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Add New Driver"
      maxWidth="max-w-3xl">
      
      {/* Progress Indicator */}
      <div className="flex items-center justify-between mb-8 relative">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-full h-0.5 bg-slate-100 dark:bg-slate-800 -z-10"></div>
        <div
          className="absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-fleet-accent -z-10 transition-all duration-300"
          style={{
            width: `${(step - 1) / 2 * 100}%`
          }}>
        </div>

        {[1, 2, 3].map((num) =>
        <div key={num} className="flex flex-col items-center">
            <div
            className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${step >= num ? 'bg-fleet-accent text-white' : 'bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-700 text-slate-400'}`}>
            
              {step > num ? <CheckCircle2 className="w-5 h-5" /> : num}
            </div>
            <span
            className={`text-xs font-medium mt-2 absolute -bottom-6 whitespace-nowrap ${step >= num ? 'text-slate-900 dark:text-white' : 'text-slate-400'}`}>
            
              {num === 1 ?
            'Personal Info' :
            num === 2 ?
            'Assignment' :
            'Biometrics'}
            </span>
          </div>
        )}
      </div>

      <div className="mt-12 min-h-[300px]">
        {step === 1 &&
        <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Full Name *
                </label>
                <input
                type="text"
                placeholder="e.g. John Doe"
                className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white" />
              
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Driver ID
                </label>
                <input
                type="text"
                defaultValue="DRV-0842"
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-md text-sm text-slate-500 dark:text-slate-400 font-mono"
                readOnly />
              
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Phone Number *
                </label>
                <input
                type="tel"
                placeholder="+1 (555) 000-0000"
                className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white" />
              
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <input
                type="email"
                placeholder="john@fleetops.com"
                className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white" />
              
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                Home Address
              </label>
              <textarea
              rows={3}
              placeholder="Full street address..."
              className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white resize-none">
            </textarea>
            </div>
          </div>
        }

        {step === 2 &&
        <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Assigned Vehicle
                </label>
                <select className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white">
                  <option value="">Select a vehicle...</option>
                  <option value="TRK-0431">TRK-0431 (Box Truck)</option>
                  <option value="TRK-0922">TRK-0922 (Sprinter Van)</option>
                  <option value="TRK-1104">TRK-1104 (Semi)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Role
                </label>
                <select className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white">
                  <option value="driver">Driver</option>
                  <option value="senior">Senior Driver</option>
                  <option value="lead">Lead Driver</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Start Date
                </label>
                <input
                type="date"
                className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white" />
              
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Default Shift
                </label>
                <select className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm focus:ring-2 focus:ring-fleet-accent focus:border-fleet-accent dark:text-white">
                  <option value="morning">Morning (6AM - 2PM)</option>
                  <option value="afternoon">Afternoon (2PM - 10PM)</option>
                  <option value="night">Night (10PM - 6AM)</option>
                </select>
              </div>
            </div>
          </div>
        }

        {step === 3 &&
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Photo Upload */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Profile Photo
                </label>
                <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 flex flex-col items-center justify-center text-center bg-slate-50 dark:bg-slate-900/50 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer h-48">
                  <Upload className="w-8 h-8 text-slate-400 mb-2" />
                  <p className="text-sm font-medium text-slate-700 dark:text-slate-300">
                    Click to upload photo
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    PNG, JPG up to 5MB
                  </p>
                </div>
              </div>

              {/* Face Registration */}
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2">
                  Face Registration
                </label>
                <div className="relative h-48 bg-slate-900 rounded-xl overflow-hidden flex flex-col items-center justify-center border border-slate-800">
                  {scanComplete ?
                <div className="flex flex-col items-center text-emerald-500 animate-in zoom-in duration-300">
                      <CheckCircle2 className="w-12 h-12 mb-2" />
                      <span className="text-sm font-medium">
                        Face Registered
                      </span>
                    </div> :

                <>
                      <div className="absolute inset-0 opacity-20 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white to-transparent"></div>
                      <ScanFace
                    className={`w-16 h-16 text-slate-400 mb-4 ${isScanning ? 'animate-pulse text-fleet-accent' : ''}`} />
                  

                      {isScanning &&
                  <div className="absolute inset-0 border-2 border-fleet-accent rounded-xl animate-ping opacity-20"></div>
                  }

                      <button
                    onClick={simulateScan}
                    disabled={isScanning}
                    className="relative z-10 px-4 py-2 bg-white/10 hover:bg-white/20 text-white text-sm font-medium rounded-full backdrop-blur-sm border border-white/20 transition-all flex items-center">
                    
                        <Camera className="w-4 h-4 mr-2" />
                        {isScanning ? 'Scanning...' : 'Capture Face Sample'}
                      </button>
                    </>
                }

                  {/* Scan dots indicator */}
                  <div className="absolute bottom-3 flex space-x-2">
                    <div
                    className={`w-1.5 h-1.5 rounded-full ${scanComplete ? 'bg-emerald-500' : isScanning ? 'bg-fleet-accent animate-pulse' : 'bg-slate-600'}`}>
                  </div>
                    <div
                    className={`w-1.5 h-1.5 rounded-full ${scanComplete ? 'bg-emerald-500' : isScanning ? 'bg-fleet-accent animate-pulse delay-75' : 'bg-slate-600'}`}>
                  </div>
                    <div
                    className={`w-1.5 h-1.5 rounded-full ${scanComplete ? 'bg-emerald-500' : isScanning ? 'bg-fleet-accent animate-pulse delay-150' : 'bg-slate-600'}`}>
                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        }
      </div>

      <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-between">
        <button
          onClick={handleBack}
          disabled={step === 1}
          className="px-4 py-2 text-sm font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center">
          
          <ChevronLeft className="w-4 h-4 mr-1" />
          Back
        </button>

        {step < 3 ?
        <button
          onClick={handleNext}
          className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-sm font-medium rounded-md hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors flex items-center shadow-sm">
          
            Next Step
            <ChevronRight className="w-4 h-4 ml-1" />
          </button> :

        <button
          onClick={handleSave}
          disabled={!scanComplete}
          className="px-6 py-2 bg-fleet-accent text-white text-sm font-medium rounded-md hover:bg-fleet-accentHover transition-colors flex items-center shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
          
            Save Driver
            <CheckCircle2 className="w-4 h-4 ml-2" />
          </button>
        }
      </div>
    </Modal>);

}
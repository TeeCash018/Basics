import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppLayout } from './components/layout/AppLayout';
import { Dashboard } from './pages/Dashboard';
import { DriverDetail } from './pages/DriverDetail';
import { Tracking } from './pages/Tracking';
import { Attendance } from './pages/Attendance';
import { FaceLogs } from './pages/FaceLogs';
import { Drivers } from './pages/Drivers';
import { Timestamps } from './pages/Timestamps';
import { Settings } from './pages/Settings';
export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<Dashboard />} />
          <Route path="attendance" element={<Attendance />} />
          <Route path="timestamps" element={<Timestamps />} />
          <Route path="tracking" element={<Tracking />} />
          <Route path="face-logs" element={<FaceLogs />} />
          <Route path="drivers" element={<Drivers />} />
          <Route path="drivers/:id" element={<DriverDetail />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </BrowserRouter>);

}
import React, { useState } from 'react';
import { mockAttendance, mockDrivers } from '../data/mockData';
import { CheckCircle2, XCircle, Search, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
export function Attendance() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const formatTime = (isoString: string | null) => {
    if (!isoString) return '--:--';
    return new Date(isoString).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30';
      case 'on-route':
        return 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-500/20 dark:text-blue-400 dark:border-blue-500/30';
      case 'late':
        return 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30';
      case 'absent':
        return 'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/20 dark:text-red-400 dark:border-red-500/30';
      case 'off-duty':
        return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30';
    }
  };
  const filteredRecords = mockAttendance.filter((record) => {
    const driver = mockDrivers.find((d) => d.id === record.driverId);
    if (!driver) return false;
    const matchesSearch =
    driver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    driver.vehicleId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
    statusFilter === 'all' || record.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  return (
    <div className="h-full overflow-y-auto bg-fleet-bg dark:bg-slate-950 p-4 md:p-6 lg:p-8 transition-colors">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              Attendance Log
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
              Comprehensive view of all driver timesheets and statuses.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full md:w-auto">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search drivers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-fleet-accent/50 focus:border-fleet-accent dark:text-white transition-colors" />
              
            </div>
            <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 w-full sm:w-auto transition-colors">
              <Filter className="w-4 h-4 text-slate-400 mr-2" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="text-sm border-none bg-transparent focus:ring-0 text-slate-700 dark:text-slate-300 font-medium cursor-pointer outline-none">
                
                <option value="all">All Statuses</option>
                <option value="present">Present</option>
                <option value="late">Late</option>
                <option value="absent">Absent</option>
                <option value="on-route">On Route</option>
              </select>
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left whitespace-nowrap">
              <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-50/50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
                <tr>
                  <th className="px-6 py-4 font-medium">Driver</th>
                  <th className="px-6 py-4 font-medium">Date</th>
                  <th className="px-6 py-4 font-medium">Status</th>
                  <th className="px-6 py-4 font-medium">Punch In</th>
                  <th className="px-6 py-4 font-medium">Punch Out</th>
                  <th className="px-6 py-4 font-medium">Hours</th>
                  <th className="px-6 py-4 font-medium">Destination</th>
                  <th className="px-6 py-4 font-medium text-center">
                    Face Verified
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredRecords.length === 0 ?
                <tr>
                    <td
                    colSpan={8}
                    className="px-6 py-12 text-center text-slate-500 dark:text-slate-400">
                    
                      No attendance records found matching your filters.
                    </td>
                  </tr> :

                filteredRecords.map((record) => {
                  const driver = mockDrivers.find(
                    (d) => d.id === record.driverId
                  );
                  if (!driver) return null;
                  return (
                    <tr
                      key={record.id}
                      onClick={() => navigate(`/drivers/${driver.id}`)}
                      className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors group">
                      
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-3">
                            <img
                            src={driver.photoUrl}
                            alt=""
                            className="w-8 h-8 rounded-full border border-slate-200 dark:border-slate-700 object-cover" />
                          
                            <div>
                              <div className="font-medium text-slate-900 dark:text-white group-hover:text-fleet-accent transition-colors">
                                {driver.name}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400">
                                {driver.vehicleId}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 font-medium text-slate-700 dark:text-slate-300">
                          {record.date}
                        </td>
                        <td className="px-6 py-4">
                          <span
                          className={`px-2.5 py-1 rounded-full text-xs uppercase tracking-wider font-semibold border ${getStatusColor(record.status)}`}>
                          
                            {record.status}
                          </span>
                        </td>
                        <td className="px-6 py-4 tabular-nums text-slate-600 dark:text-slate-300">
                          {formatTime(record.punchInTime)}
                        </td>
                        <td className="px-6 py-4 tabular-nums text-slate-600 dark:text-slate-300">
                          {formatTime(record.punchOutTime)}
                        </td>
                        <td className="px-6 py-4 tabular-nums font-medium text-slate-900 dark:text-white">
                          {record.totalHours > 0 ?
                        `${record.totalHours}h` :
                        '-'}
                        </td>
                        <td className="px-6 py-4 text-slate-600 dark:text-slate-300 truncate max-w-[200px]">
                          {record.assignedDestination}
                        </td>
                        <td className="px-6 py-4 text-center">
                          {record.faceVerified ?
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 mx-auto" /> :
                        record.status === 'absent' ?
                        <span className="text-slate-300 dark:text-slate-600">
                              -
                            </span> :

                        <XCircle className="w-5 h-5 text-red-500 mx-auto" />
                        }
                        </td>
                      </tr>);

                })
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>);

}
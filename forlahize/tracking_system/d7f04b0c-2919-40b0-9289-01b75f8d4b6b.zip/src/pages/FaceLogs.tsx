import React, { useState } from 'react';
import { mockFaceVerificationLogs, mockDrivers } from '../data/mockData';
import { CheckCircle2, XCircle, Clock, MapPin, Search } from 'lucide-react';
export function FaceLogs() {
  const [searchTerm, setSearchTerm] = useState('');
  const formatTime = (isoString: string) => {
    return (
      new Date(isoString).toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
      }) +
      ' - ' +
      new Date(isoString).toLocaleDateString());

  };
  const filteredLogs = mockFaceVerificationLogs.filter((log) => {
    const driver = mockDrivers.find((d) => d.id === log.driverId);
    if (!driver) return false;
    return driver.name.toLowerCase().includes(searchTerm.toLowerCase());
  });
  return (
    <div className="h-full overflow-y-auto bg-fleet-bg dark:bg-slate-950 p-4 md:p-6 lg:p-8 transition-colors">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              Face Verification Logs
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
              Review punch-in and arrival face captures.
            </p>
          </div>

          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by driver name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-fleet-accent/50 focus:border-fleet-accent dark:text-white transition-colors" />
            
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredLogs.map((log) => {
            const driver = mockDrivers.find((d) => d.id === log.driverId);
            if (!driver) return null;
            return (
              <div
                key={log.id}
                className={`bg-white dark:bg-slate-900 rounded-xl border shadow-sm overflow-hidden flex flex-col transition-colors ${log.status === 'failed' ? 'border-red-200 dark:border-red-900/50' : 'border-slate-200 dark:border-slate-800'}`}>
                
                <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-start">
                  <div className="flex items-center space-x-3">
                    <img
                      src={driver.photoUrl}
                      alt=""
                      className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 object-cover" />
                    
                    <div>
                      <div className="font-medium text-slate-900 dark:text-white">
                        {driver.name}
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">
                        {log.punchType.replace('-', ' ')}
                      </div>
                    </div>
                  </div>
                  <div
                    className={`px-2.5 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold flex items-center border ${log.status === 'verified' ? 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30' : log.status === 'failed' ? 'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/20 dark:text-red-400 dark:border-red-500/30' : 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30'}`}>
                    
                    {log.status === 'verified' &&
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    }
                    {log.status === 'failed' &&
                    <XCircle className="w-3 h-3 mr-1" />
                    }
                    {log.status === 'pending' &&
                    <Clock className="w-3 h-3 mr-1" />
                    }
                    {log.status}
                  </div>
                </div>

                <div className="p-4 flex space-x-4 bg-slate-50 dark:bg-slate-900/50">
                  <div className="flex-1">
                    <div className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">
                      Captured Photo
                    </div>
                    <div className="relative aspect-square rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                      <img
                        src={log.capturedPhotoUrl}
                        alt="Captured"
                        className="w-full h-full object-cover" />
                      
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">
                      Reference Profile
                    </div>
                    <div className="relative aspect-square rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 opacity-80">
                      <img
                        src={log.referencePhotoUrl}
                        alt="Reference"
                        className="w-full h-full object-cover grayscale-[20%]" />
                      
                    </div>
                  </div>
                </div>

                <div className="p-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-500 dark:text-slate-400">
                      Confidence Match
                    </span>
                    <div className="flex items-center">
                      <div className="w-24 h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full mr-3 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${log.confidenceScore >= 90 ? 'bg-emerald-500' : log.confidenceScore >= 70 ? 'bg-amber-500' : 'bg-red-500'}`}
                          style={{
                            width: `${log.confidenceScore}%`
                          }}>
                        </div>
                      </div>
                      <span
                        className={`text-sm font-bold tabular-nums ${log.confidenceScore >= 90 ? 'text-emerald-600 dark:text-emerald-400' : log.confidenceScore >= 70 ? 'text-amber-600 dark:text-amber-400' : 'text-red-600 dark:text-red-400'}`}>
                        
                        {log.confidenceScore}%
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col space-y-1.5 text-xs text-slate-500 dark:text-slate-400">
                    <div className="flex items-center">
                      <Clock className="w-3.5 h-3.5 mr-2 text-slate-400" />
                      <span className="tabular-nums">
                        {formatTime(log.timestamp)}
                      </span>
                    </div>
                    <div className="flex items-start">
                      <MapPin className="w-3.5 h-3.5 mr-2 text-slate-400 mt-0.5 flex-shrink-0" />
                      <span className="line-clamp-2">
                        {log.location.address}
                      </span>
                    </div>
                  </div>

                  {log.status === 'pending' &&
                  <div className="pt-3 mt-3 border-t border-slate-100 dark:border-slate-800 flex space-x-2">
                      <button className="flex-1 py-1.5 bg-emerald-50 dark:bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/20 rounded text-xs font-medium hover:bg-emerald-100 dark:hover:bg-emerald-500/20 transition-colors">
                        Approve
                      </button>
                      <button className="flex-1 py-1.5 bg-red-50 dark:bg-red-500/10 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-500/20 rounded text-xs font-medium hover:bg-red-100 dark:hover:bg-red-500/20 transition-colors">
                        Reject
                      </button>
                    </div>
                  }
                </div>
              </div>);

          })}
        </div>
      </div>
    </div>);

}
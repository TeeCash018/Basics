import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft,
  Phone,
  Mail,
  Truck,
  Clock,
  Gauge,
  MapPin,
  CheckCircle2,
  XCircle } from
'lucide-react';
import {
  mockDrivers,
  mockAttendance,
  mockPunchRecords,
  mockFaceVerificationLogs } from
'../data/mockData';
import { FleetMap } from '../components/dashboard/FleetMap';
import { StatCard } from '../components/dashboard/StatCard';
export function DriverDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const driver = mockDrivers.find((d) => d.id === id);
  const driverAttendance = mockAttendance.filter((a) => a.driverId === id);
  const driverPunches = mockPunchRecords.filter((p) => p.driverId === id);
  const driverFaceLogs = mockFaceVerificationLogs.filter(
    (f) => f.driverId === id
  );
  if (!driver) {
    return (
      <div className="p-8 text-center bg-fleet-bg dark:bg-slate-950 h-full">
        <h2 className="text-xl font-semibold text-slate-700 dark:text-slate-300">
          Driver not found
        </h2>
        <button
          onClick={() => navigate('/tracking')}
          className="mt-4 text-fleet-accent hover:underline">
          
          Return to Tracking
        </button>
      </div>);

  }
  const statusColors = {
    active:
    'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30',
    idle: 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30',
    alert:
    'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/20 dark:text-red-400 dark:border-red-500/30',
    offline:
    'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30'
  };
  const formatTime = (isoString: string | null) => {
    if (!isoString) return '--:--';
    return new Date(isoString).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  return (
    <div className="h-full overflow-y-auto bg-fleet-bg dark:bg-slate-950 p-4 md:p-6 lg:p-8 transition-colors">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center text-sm font-medium text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white mb-6 transition-colors">
        
        <ArrowLeft className="w-4 h-4 mr-1.5" />
        Back
      </button>

      {/* Header Card */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-6 mb-6 transition-colors">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center space-x-5">
            <img
              src={driver.photoUrl}
              alt={driver.name}
              className="w-20 h-20 rounded-full object-cover border-4 border-slate-50 dark:border-slate-800 shadow-sm" />
            
            <div>
              <h1 className="text-2xl font-bold text-slate-900 dark:text-white mb-1">
                {driver.name}
              </h1>
              <div className="flex items-center space-x-3 text-sm">
                <span
                  className={`px-2.5 py-0.5 rounded-full border font-medium capitalize ${statusColors[driver.status]}`}>
                  
                  {driver.status}
                </span>
                <span className="text-slate-500 dark:text-slate-400 flex items-center">
                  <Truck className="w-4 h-4 mr-1" />
                  {driver.vehicleId}
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-col space-y-2 text-sm text-slate-600 dark:text-slate-400 border-t md:border-t-0 md:border-l border-slate-100 dark:border-slate-800 pt-4 md:pt-0 md:pl-6">
            <div className="flex items-center">
              <Phone className="w-4 h-4 mr-2 text-slate-400" />
              {driver.phone}
            </div>
            <div className="flex items-center">
              <Mail className="w-4 h-4 mr-2 text-slate-400" />
              {driver.name.toLowerCase().replace(' ', '.')}@fleetops.com
            </div>
          </div>
        </div>
      </div>

      {/* Driver Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <StatCard
          title="Days Present This Month"
          value="18"
          icon={CheckCircle2}
          colorClass="text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-400" />
        
        <StatCard
          title="Avg Punch-In Time"
          value="06:42 AM"
          icon={Clock}
          colorClass="text-blue-600 bg-blue-50 dark:bg-blue-500/10 dark:text-blue-400" />
        
        <StatCard
          title="On-Time Arrival %"
          value="94%"
          icon={MapPin}
          colorClass="text-amber-600 bg-amber-50 dark:bg-amber-500/10 dark:text-amber-400" />
        
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Timeline */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
              <h3 className="font-semibold text-slate-900 dark:text-white">
                Today's Timeline
              </h3>
            </div>
            <div className="p-6">
              {driverPunches.length === 0 ?
              <div className="text-center py-4 text-sm text-slate-500 dark:text-slate-400">
                  No activity today
                </div> :

              <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-3 space-y-8">
                  {driverPunches.
                sort(
                  (a, b) =>
                  new Date(a.timestamp).getTime() -
                  new Date(b.timestamp).getTime()
                ).
                map((punch, idx) =>
                <div key={punch.id} className="relative pl-6">
                        <div
                    className={`absolute -left-[9px] top-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-900 ${punch.type === 'punch-in' ? 'bg-emerald-500' : punch.type === 'punch-out' ? 'bg-slate-500' : 'bg-blue-500'}`}>
                  </div>
                        <div className="flex justify-between items-start mb-1">
                          <div className="font-medium text-slate-900 dark:text-white capitalize">
                            {punch.type.replace('-', ' ')}
                          </div>
                          <div className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                            {formatTime(punch.timestamp)}
                          </div>
                        </div>
                        <div className="text-xs text-slate-500 dark:text-slate-400 flex items-start mt-1">
                          <MapPin className="w-3.5 h-3.5 mr-1 mt-0.5 flex-shrink-0 text-slate-400" />
                          <span>{punch.location.address}</span>
                        </div>
                        {punch.facePhotoUrl &&
                  <div className="mt-3 flex items-center space-x-2">
                            <img
                      src={punch.facePhotoUrl}
                      alt="Face capture"
                      className="w-8 h-8 rounded border border-slate-200 dark:border-slate-700 object-cover" />
                    
                            <span
                      className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded border ${punch.verificationStatus === 'verified' ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border-emerald-500/20' : punch.verificationStatus === 'failed' ? 'bg-red-50 text-red-700 border-red-200 dark:bg-red-500/10 dark:text-red-400 dark:border-red-500/20' : 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-500/10 dark:text-amber-400 dark:border-amber-500/20'}`}>
                      
                              {punch.verificationStatus}
                            </span>
                          </div>
                  }
                      </div>
                )}
                </div>
              }
            </div>
          </div>
        </div>

        {/* Right Column: Map & Attendance */}
        <div className="lg:col-span-2 space-y-6">
          {/* Live Map */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col h-[300px] transition-colors">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-900/50">
              <h3 className="font-semibold text-slate-900 dark:text-white flex items-center">
                <MapPin className="w-4 h-4 mr-2 text-slate-400" />
                Live Location & Route
              </h3>
              <div className="flex items-center space-x-4 text-sm">
                <span className="flex items-center text-slate-600 dark:text-slate-400">
                  <Gauge className="w-4 h-4 mr-1 text-slate-400" />
                  <span className="tabular-nums font-medium">
                    {driver.currentSpeed} mph
                  </span>
                </span>
              </div>
            </div>
            <div className="flex-1 relative z-0">
              <FleetMap
                drivers={[driver]}
                selectedDriverId={driver.id}
                alertsByDriver={{}}
                showRoutes={true} />
              
            </div>
          </div>

          {/* Attendance History */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50">
              <h3 className="font-semibold text-slate-900 dark:text-white">
                Attendance History
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-50/50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3 font-medium">Date</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 font-medium">Punch In</th>
                    <th className="px-4 py-3 font-medium">Punch Out</th>
                    <th className="px-4 py-3 font-medium">Hours</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {driverAttendance.length === 0 ?
                  <tr>
                      <td
                      colSpan={5}
                      className="px-4 py-8 text-center text-slate-500 dark:text-slate-400">
                      
                        No attendance records found
                      </td>
                    </tr> :

                  driverAttendance.map((record) =>
                  <tr
                    key={record.id}
                    className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                    
                        <td className="px-4 py-3 font-medium text-slate-900 dark:text-white">
                          {record.date}
                        </td>
                        <td className="px-4 py-3">
                          <span
                        className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] uppercase tracking-wider font-semibold border ${record.status === 'present' ? 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30' : record.status === 'late' ? 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30' : 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30'}`}>
                        
                            {record.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 tabular-nums text-slate-600 dark:text-slate-300">
                          {formatTime(record.punchInTime)}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-slate-600 dark:text-slate-300">
                          {formatTime(record.punchOutTime)}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-slate-900 dark:text-white font-medium">
                          {record.totalHours}h
                        </td>
                      </tr>
                  )
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>);

}
import React, { useState } from 'react';
import { mockArrivalTimestamps, mockDrivers } from '../data/mockData';
import {
  MapPin,
  Clock,
  Filter,
  CheckCircle2,
  AlertTriangle,
  XCircle } from
'lucide-react';
import { StatCard } from '../components/dashboard/StatCard';
import { motion } from 'framer-motion';
export function Timestamps() {
  const [statusFilter, setStatusFilter] = useState('all');
  const formatTime = (isoString: string | null) => {
    if (!isoString) return '--:--';
    return new Date(isoString).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'on-time':
        return {
          color:
          'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30',
          icon: CheckCircle2
        };
      case 'late':
        return {
          color:
          'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30',
          icon: AlertTriangle
        };
      case 'pending':
        return {
          color:
          'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-500/20 dark:text-blue-400 dark:border-blue-500/30',
          icon: Clock
        };
      case 'missed':
        return {
          color:
          'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/20 dark:text-red-400 dark:border-red-500/30',
          icon: XCircle
        };
      default:
        return {
          color: 'bg-slate-100 text-slate-700 border-slate-200',
          icon: Clock
        };
    }
  };
  const filteredTimestamps = mockArrivalTimestamps.filter(
    (t) => statusFilter === 'all' || t.status === statusFilter
  );
  const onTimeCount = mockArrivalTimestamps.filter(
    (t) => t.status === 'on-time'
  ).length;
  const lateCount = mockArrivalTimestamps.filter(
    (t) => t.status === 'late'
  ).length;
  const missedCount = mockArrivalTimestamps.filter(
    (t) => t.status === 'missed'
  ).length;
  const onTimePercent =
  Math.round(
    onTimeCount / (
    mockArrivalTimestamps.length -
    mockArrivalTimestamps.filter((t) => t.status === 'pending').length) *
    100
  ) || 0;
  return (
    <div className="h-full overflow-y-auto bg-fleet-bg dark:bg-slate-950 p-4 md:p-6 lg:p-8 transition-colors">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              Location Timestamps
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
              Real-time arrival logging at assigned destinations.
            </p>
          </div>

          <div className="flex items-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg px-3 py-2 shadow-sm">
            <Filter className="w-4 h-4 text-slate-400 mr-2" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-sm border-none bg-transparent focus:ring-0 text-slate-700 dark:text-slate-300 font-medium cursor-pointer outline-none">
              
              <option value="all">All Statuses</option>
              <option value="on-time">On Time</option>
              <option value="late">Late</option>
              <option value="pending">Pending</option>
              <option value="missed">Missed</option>
            </select>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Total Arrivals Today"
            value={mockArrivalTimestamps.length}
            icon={MapPin}
            colorClass="text-blue-600 bg-blue-50 dark:bg-blue-500/10 dark:text-blue-400" />
          
          <StatCard
            title="On-Time %"
            value={`${onTimePercent}%`}
            icon={CheckCircle2}
            colorClass="text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-400"
            trend={{
              value: '5%',
              isPositive: true
            }} />
          
          <StatCard
            title="Late Arrivals"
            value={lateCount}
            icon={AlertTriangle}
            colorClass="text-amber-600 bg-amber-50 dark:bg-amber-500/10 dark:text-amber-400" />
          
          <StatCard
            title="Missed Arrivals"
            value={missedCount}
            icon={XCircle}
            colorClass="text-red-600 bg-red-50 dark:bg-red-500/10 dark:text-red-400" />
          
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredTimestamps.map((timestamp, i) => {
            const driver = mockDrivers.find((d) => d.id === timestamp.driverId);
            if (!driver) return null;
            const statusConfig = getStatusConfig(timestamp.status);
            const StatusIcon = statusConfig.icon;
            return (
              <motion.div
                key={timestamp.id}
                initial={{
                  opacity: 0,
                  y: 10
                }}
                animate={{
                  opacity: 1,
                  y: 0
                }}
                transition={{
                  delay: i * 0.05,
                  duration: 0.2
                }}
                className={`bg-white dark:bg-slate-900 rounded-xl border shadow-sm p-5 transition-colors ${timestamp.status === 'pending' ? 'border-blue-200 dark:border-blue-800 shadow-[0_0_15px_rgba(59,130,246,0.1)]' : 'border-slate-200 dark:border-slate-800'}`}>
                
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white truncate pr-4">
                    {timestamp.destination}
                  </h3>
                  <span
                    className={`flex items-center px-2.5 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold border flex-shrink-0 ${statusConfig.color} ${timestamp.status === 'pending' ? 'animate-pulse' : ''}`}>
                    
                    <StatusIcon className="w-3 h-3 mr-1" />
                    {timestamp.status}
                  </span>
                </div>

                <div className="flex items-center space-x-3 mb-5 pb-5 border-b border-slate-100 dark:border-slate-800">
                  <img
                    src={driver.photoUrl}
                    alt=""
                    className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700" />
                  
                  <div>
                    <div className="font-medium text-slate-900 dark:text-white">
                      {driver.name}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400">
                      {driver.vehicleId}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-5">
                  <div>
                    <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Scheduled
                    </div>
                    <div className="text-slate-900 dark:text-white font-medium tabular-nums">
                      {formatTime(timestamp.scheduledTime)}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Actual
                    </div>
                    <div className="flex items-center">
                      <span className="text-slate-900 dark:text-white font-medium tabular-nums mr-2">
                        {formatTime(timestamp.actualArrivalTime)}
                      </span>
                      {timestamp.delay && timestamp.delay > 0 &&
                      <span className="text-xs font-bold text-amber-600 dark:text-amber-400">
                          +{timestamp.delay}m
                        </span>
                      }
                    </div>
                  </div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-950 rounded-lg p-3 border border-slate-100 dark:border-slate-800">
                  <div className="flex items-start text-sm">
                    <MapPin className="w-4 h-4 text-slate-400 mr-2 mt-0.5 flex-shrink-0" />
                    <div>
                      <div className="text-slate-700 dark:text-slate-300 mb-1 line-clamp-1">
                        {timestamp.location.address}
                      </div>
                      <div className="text-xs font-mono text-slate-500 dark:text-slate-500 tabular-nums">
                        {timestamp.location.lat.toFixed(4)}°N,{' '}
                        {timestamp.location.lng.toFixed(4)}°W
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>);

          })}
        </div>
      </div>
    </div>);

}
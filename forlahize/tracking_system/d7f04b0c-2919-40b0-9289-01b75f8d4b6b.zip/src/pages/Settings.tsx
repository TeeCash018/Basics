import React, { useState } from 'react';
import {
  Building2,
  User,
  Users,
  ScanFace,
  MapPin,
  Bell,
  Clock,
  Shield,
  Database,
  Save } from
'lucide-react';
import { Toggle } from '../components/ui/Toggle';
import { Slider } from '../components/ui/Slider';
import { toast } from 'sonner';
const SECTIONS = [
{
  id: 'company',
  label: 'Company Profile',
  icon: Building2
},
{
  id: 'admin',
  label: 'Admin Account',
  icon: User
},
{
  id: 'drivers',
  label: 'Driver Management',
  icon: Users
},
{
  id: 'face',
  label: 'Facial Recognition',
  icon: ScanFace
},
{
  id: 'gps',
  label: 'GPS & Location',
  icon: MapPin
},
{
  id: 'notifications',
  label: 'Notifications',
  icon: Bell
},
{
  id: 'hours',
  label: 'Work Hours & Rules',
  icon: Clock
},
{
  id: 'security',
  label: 'Security & Privacy',
  icon: Shield
},
{
  id: 'backup',
  label: 'Backup & Sync',
  icon: Database
}];

export function Settings() {
  const [activeSection, setActiveSection] = useState('company');
  // Mock state for toggles/sliders
  const [toggles, setToggles] = useState<Record<string, boolean>>({
    requirePhoto: true,
    livenessDetection: true,
    storeEmbeddings: false,
    emailNotif: true,
    smsNotif: false,
    pushNotif: true,
    encryption: true,
    gdpr: false
  });
  const [sliders, setSliders] = useState<Record<string, number>>({
    confidence: 85,
    pingInterval: 30,
    geofence: 100
  });
  const handleToggle = (key: string) =>
  setToggles((prev) => ({
    ...prev,
    [key]: !prev[key]
  }));
  const handleSlider = (key: string, val: number) =>
  setSliders((prev) => ({
    ...prev,
    [key]: val
  }));
  const handleSave = () => {
    toast.success('Settings saved successfully');
  };
  const renderContent = () => {
    switch (activeSection) {
      case 'company':
        return (
          <div className="space-y-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-4">
              Company Profile
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Company Name
                </label>
                <input
                  type="text"
                  defaultValue="FleetOps Logistics"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm dark:text-white" />
                
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Timezone
                </label>
                <select className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm dark:text-white">
                  <option>America/Chicago (CST)</option>
                  <option>America/New_York (EST)</option>
                  <option>America/Los_Angeles (PST)</option>
                </select>
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Headquarters Address
                </label>
                <textarea
                  rows={2}
                  defaultValue="123 Logistics Way, Austin, TX 78701"
                  className="w-full px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm dark:text-white resize-none">
                </textarea>
              </div>
            </div>
          </div>);

      case 'face':
        return (
          <div className="space-y-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-4">
              Facial Recognition
            </h2>
            <div className="space-y-8">
              <Slider
                label="Confidence Threshold"
                value={sliders.confidence}
                onChange={(v) => handleSlider('confidence', v)}
                min={50}
                max={99} />
              
              <div className="space-y-4">
                <Toggle
                  label="Liveness Detection"
                  description="Require blink or head movement during scan to prevent photo spoofing."
                  checked={toggles.livenessDetection}
                  onChange={() => handleToggle('livenessDetection')} />
                
                <Toggle
                  label="Store Face Embeddings"
                  description="Save mathematical face models instead of raw photos for privacy."
                  checked={toggles.storeEmbeddings}
                  onChange={() => handleToggle('storeEmbeddings')} />
                
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Max Retries Before Lockout
                </label>
                <select className="w-full md:w-1/2 px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm dark:text-white">
                  <option>3 attempts</option>
                  <option>5 attempts</option>
                  <option>Unlimited</option>
                </select>
              </div>
            </div>
          </div>);

      case 'gps':
        return (
          <div className="space-y-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-4">
              GPS & Location
            </h2>
            <div className="space-y-8">
              <Slider
                label="Ping Interval"
                unit="s"
                value={sliders.pingInterval}
                onChange={(v) => handleSlider('pingInterval', v)}
                min={10}
                max={120}
                step={10} />
              
              <Slider
                label="Geofence Arrival Radius"
                unit="m"
                value={sliders.geofence}
                onChange={(v) => handleSlider('geofence', v)}
                min={50}
                max={500}
                step={50} />
              
              <div>
                <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
                  Location History Retention
                </label>
                <select className="w-full md:w-1/2 px-3 py-2 bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-md text-sm dark:text-white">
                  <option>30 Days</option>
                  <option>90 Days</option>
                  <option>1 Year</option>
                </select>
              </div>
            </div>
          </div>);

      // Fallback for other sections to keep code concise but show they exist
      default:
        return (
          <div className="space-y-6">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-4 capitalize">
              {activeSection.replace('-', ' ')} Settings
            </h2>
            <div className="py-8 text-center text-slate-500 dark:text-slate-400">
              <p>Configuration options for {activeSection} will appear here.</p>
            </div>
          </div>);

    }
  };
  return (
    <div className="h-full overflow-y-auto bg-fleet-bg dark:bg-slate-950 transition-colors">
      <div className="max-w-6xl mx-auto p-4 md:p-6 lg:p-8">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            Settings
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
            Manage system configuration and preferences.
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          {/* Sidebar Nav */}
          <div className="w-full md:w-64 flex-shrink-0">
            <nav className="space-y-1 bg-white dark:bg-slate-900 p-2 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
              {SECTIONS.map((section) => {
                const Icon = section.icon;
                const isActive = activeSection === section.id;
                return (
                  <button
                    key={section.id}
                    onClick={() => setActiveSection(section.id)}
                    className={`w-full flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-colors ${isActive ? 'bg-fleet-accent/10 text-fleet-accent dark:bg-fleet-accent/20' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-200'}`}>
                    
                    <Icon
                      className={`w-4 h-4 mr-3 ${isActive ? 'text-fleet-accent' : 'text-slate-400'}`} />
                    
                    {section.label}
                  </button>);

              })}
            </nav>
          </div>

          {/* Content Panel */}
          <div className="flex-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col min-h-[500px]">
            <div className="flex-1 p-6">{renderContent()}</div>
            <div className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 rounded-b-xl flex justify-end sticky bottom-0">
              <button
                onClick={handleSave}
                className="px-6 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 text-sm font-medium rounded-md hover:bg-slate-800 dark:hover:bg-slate-100 transition-colors flex items-center shadow-sm">
                
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>);

}
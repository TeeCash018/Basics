import React, { useState } from 'react';
import { DriverRoster } from '../components/dashboard/DriverRoster';
import { FleetMap } from '../components/dashboard/FleetMap';
import { mockDrivers } from '../data/mockData';
export function Tracking() {
  const [selectedDriverId, setSelectedDriverId] = useState<string | null>(null);
  return (
    <div className="flex flex-col h-full bg-fleet-bg dark:bg-slate-950 transition-colors">
      <div className="p-4 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex-shrink-0 flex justify-between items-center transition-colors">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-white">
            Live Tracking
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm">
            Monitor fleet locations in real-time.
          </p>
        </div>
        <div className="flex items-center px-3 py-1 bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-emerald-500/20 rounded-full">
          <div className="w-2 h-2 rounded-full bg-emerald-500 mr-2 animate-pulse"></div>
          <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400 tabular-nums">
            Live • {mockDrivers.filter((d) => d.status === 'active').length}{' '}
            active
          </span>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden flex-col md:flex-row">
        <DriverRoster
          drivers={mockDrivers}
          selectedDriverId={selectedDriverId}
          onSelectDriver={(id) =>
          setSelectedDriverId(id === selectedDriverId ? null : id)
          }
          alertsByDriver={{}} />
        
        <div className="flex-1 relative bg-slate-100 dark:bg-slate-800 h-[50vh] md:h-auto">
          <FleetMap
            drivers={mockDrivers}
            selectedDriverId={selectedDriverId}
            alertsByDriver={{}} />
          
        </div>
      </div>
    </div>);

}
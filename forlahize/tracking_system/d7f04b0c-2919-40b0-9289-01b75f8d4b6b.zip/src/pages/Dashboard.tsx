import React, { useState } from 'react';
import {
  Users,
  Clock,
  AlertCircle,
  Calendar,
  CheckCircle2,
  XCircle,
  MapPin } from
'lucide-react';
import { StatCard } from '../components/dashboard/StatCard';
import { mockAttendance, mockDrivers, mockPunchRecords } from '../data/mockData';
import { useNavigate } from 'react-router-dom';
export function Dashboard() {
  const navigate = useNavigate();
  const [dateFilter, setDateFilter] = useState('today');
  const presentCount = mockAttendance.filter(
    (a) => a.status === 'present' || a.status === 'on-route'
  ).length;
  const lateCount = mockAttendance.filter((a) => a.status === 'late').length;
  const absentCount = mockAttendance.filter((a) => a.status === 'absent').length;
  const avgHours = (
  mockAttendance.reduce((acc, a) => acc + a.totalHours, 0) /
  mockAttendance.filter((a) => a.totalHours > 0).length).
  toFixed(1);
  const formatTime = (isoString: string | null) => {
    if (!isoString) return '--:--';
    return new Date(isoString).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30';
      case 'on-route':
        return 'bg-blue-100 text-blue-700 border-blue-200 dark:bg-blue-500/20 dark:text-blue-400 dark:border-blue-500/30';
      case 'late':
        return 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30';
      case 'absent':
        return 'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/20 dark:text-red-400 dark:border-red-500/30';
      case 'off-duty':
        return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30';
    }
  };
  const recentPunches = [...mockPunchRecords].
  sort(
    (a, b) =>
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  ).
  slice(0, 5);
  return (
    <div className="flex flex-col h-full overflow-y-auto bg-fleet-bg dark:bg-slate-950 p-4 md:p-6 lg:p-8 transition-colors">
      <div className="max-w-7xl mx-auto w-full space-y-6">
        {/* Header & Date Selector */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              Timesheet Overview
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
              Daily attendance and punch-in tracking.
            </p>
          </div>
          <div className="flex items-center bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800 p-1 shadow-sm">
            <button
              onClick={() => setDateFilter('yesterday')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${dateFilter === 'yesterday' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>
              
              Yesterday
            </button>
            <button
              onClick={() => setDateFilter('today')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${dateFilter === 'today' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>
              
              Today
            </button>
            <button
              onClick={() => setDateFilter('week')}
              className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${dateFilter === 'week' ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}>
              
              This Week
            </button>
            <div className="w-px h-4 bg-slate-200 dark:bg-slate-700 mx-2"></div>
            <button className="p-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200">
              <Calendar className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard
            title="Present Today"
            value={`${presentCount} / ${mockDrivers.length}`}
            icon={Users}
            colorClass="text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-400" />
          
          <StatCard
            title="Late Arrivals"
            value={lateCount}
            icon={Clock}
            colorClass="text-amber-600 bg-amber-50 dark:bg-amber-500/10 dark:text-amber-400" />
          
          <StatCard
            title="Absent"
            value={absentCount}
            icon={AlertCircle}
            colorClass="text-red-600 bg-red-50 dark:bg-red-500/10 dark:text-red-400" />
          
          <StatCard
            title="Avg Hours Worked"
            value={`${avgHours}h`}
            icon={Clock}
            colorClass="text-blue-600 bg-blue-50 dark:bg-blue-500/10 dark:text-blue-400" />
          
        </div>

        {/* Main Content Split */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Timesheet Table (Left 2/3) */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col transition-colors">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex justify-between items-center">
              <h2 className="font-semibold text-slate-900 dark:text-white">
                Today's Timesheet
              </h2>
              <button
                onClick={() => navigate('/attendance')}
                className="text-sm text-fleet-accent font-medium hover:underline">
                
                View Full Log
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left whitespace-nowrap">
                <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-50/50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
                  <tr>
                    <th className="px-4 py-3 font-medium">Driver</th>
                    <th className="px-4 py-3 font-medium">Status</th>
                    <th className="px-4 py-3 font-medium">Punch In</th>
                    <th className="px-4 py-3 font-medium">Arrival</th>
                    <th className="px-4 py-3 font-medium">Punch Out</th>
                    <th className="px-4 py-3 font-medium">Hours</th>
                    <th className="px-4 py-3 font-medium text-center">
                      Face Verified
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {mockAttendance.map((record) => {
                    const driver = mockDrivers.find(
                      (d) => d.id === record.driverId
                    );
                    if (!driver) return null;
                    return (
                      <tr
                        key={record.id}
                        onClick={() => navigate(`/drivers/${driver.id}`)}
                        className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors group">
                        
                        <td className="px-4 py-3">
                          <div className="flex items-center space-x-3">
                            <img
                              src={driver.photoUrl}
                              alt=""
                              className="w-8 h-8 rounded-full border border-slate-200 dark:border-slate-700 object-cover" />
                            
                            <div>
                              <div className="font-medium text-slate-900 dark:text-white group-hover:text-fleet-accent transition-colors">
                                {driver.name}
                              </div>
                              <div className="text-xs text-slate-500 dark:text-slate-400">
                                {driver.vehicleId}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider font-semibold border ${getStatusColor(record.status)}`}>
                            
                            {record.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 tabular-nums text-slate-600 dark:text-slate-300">
                          {formatTime(record.punchInTime)}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-slate-600 dark:text-slate-300">
                          {formatTime(record.arrivalTime)}
                        </td>
                        <td className="px-4 py-3 tabular-nums text-slate-600 dark:text-slate-300">
                          {formatTime(record.punchOutTime)}
                        </td>
                        <td className="px-4 py-3 tabular-nums font-medium text-slate-900 dark:text-white">
                          {record.totalHours > 0 ?
                          `${record.totalHours}h` :
                          '-'}
                        </td>
                        <td className="px-4 py-3 text-center">
                          {record.faceVerified ?
                          <CheckCircle2 className="w-5 h-5 text-emerald-500 mx-auto" /> :
                          record.status === 'absent' ?
                          <span className="text-slate-300 dark:text-slate-600">
                              -
                            </span> :

                          <XCircle className="w-5 h-5 text-red-500 mx-auto" />
                          }
                        </td>
                      </tr>);

                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Recent Activity (Right 1/3) */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col transition-colors">
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/50 flex justify-between items-center">
              <h2 className="font-semibold text-slate-900 dark:text-white">
                Recent Punches
              </h2>
              <button
                onClick={() => navigate('/face-logs')}
                className="text-sm text-fleet-accent font-medium hover:underline">
                
                All Logs
              </button>
            </div>
            <div className="p-4 space-y-4 flex-1 overflow-y-auto">
              {recentPunches.map((punch) => {
                const driver = mockDrivers.find((d) => d.id === punch.driverId);
                if (!driver) return null;
                return (
                  <div key={punch.id} className="flex items-start space-x-3">
                    <div className="relative">
                      <img
                        src={punch.facePhotoUrl}
                        alt=""
                        className="w-10 h-10 rounded-md object-cover border border-slate-200 dark:border-slate-700" />
                      
                      <div
                        className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-900 flex items-center justify-center ${punch.verificationStatus === 'verified' ? 'bg-emerald-500' : punch.verificationStatus === 'failed' ? 'bg-red-500' : 'bg-amber-500'}`}>
                        
                        {punch.verificationStatus === 'verified' &&
                        <CheckCircle2 className="w-3 h-3 text-white" />
                        }
                        {punch.verificationStatus === 'failed' &&
                        <XCircle className="w-3 h-3 text-white" />
                        }
                        {punch.verificationStatus === 'pending' &&
                        <Clock className="w-3 h-3 text-white" />
                        }
                      </div>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <p className="text-sm font-medium text-slate-900 dark:text-white truncate">
                          {driver.name}
                        </p>
                        <span className="text-xs text-slate-500 dark:text-slate-400 tabular-nums">
                          {formatTime(punch.timestamp)}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 capitalize">
                        {punch.type.replace('-', ' ')}
                      </p>
                      <div className="flex items-center text-xs text-slate-400 mt-1 truncate">
                        <MapPin className="w-3 h-3 mr-1 flex-shrink-0" />
                        <span className="truncate">
                          {punch.location.address}
                        </span>
                      </div>
                    </div>
                  </div>);

              })}
            </div>
          </div>
        </div>
      </div>
    </div>);

}
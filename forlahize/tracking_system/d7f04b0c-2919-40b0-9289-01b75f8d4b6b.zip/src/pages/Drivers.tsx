import React, { useState } from 'react';
import { mockDrivers, mockPunchRecords } from '../data/mockData';
import {
  Search,
  Filter,
  PlusCircle,
  LayoutGrid,
  List,
  MapPin,
  MoreVertical } from
'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AddDriverModal } from '../components/drivers/AddDriverModal';
import { motion } from 'framer-motion';
export function Drivers() {
  const navigate = useNavigate();
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/20 dark:text-emerald-400 dark:border-emerald-500/30';
      case 'idle':
        return 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/20 dark:text-amber-400 dark:border-amber-500/30';
      case 'alert':
        return 'bg-red-100 text-red-700 border-red-200 dark:bg-red-500/20 dark:text-red-400 dark:border-red-500/30';
      case 'offline':
        return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-500/20 dark:text-slate-400 dark:border-slate-500/30';
    }
  };
  const getLastPunchIn = (driverId: string) => {
    const punches = mockPunchRecords.filter(
      (p) => p.driverId === driverId && p.type === 'punch-in'
    );
    if (punches.length === 0) return '--:--';
    const latest = punches.sort(
      (a, b) =>
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    )[0];
    return new Date(latest.timestamp).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit'
    });
  };
  const filteredDrivers = mockDrivers.filter((driver) => {
    const matchesSearch =
    driver.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    driver.vehicleId.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus =
    statusFilter === 'all' || driver.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  return (
    <div className="h-full overflow-y-auto bg-fleet-bg dark:bg-slate-950 p-4 md:p-6 lg:p-8 transition-colors">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
              Drivers
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
              Manage your fleet workforce and profiles.
            </p>
          </div>
          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-4 py-2 bg-fleet-accent text-white text-sm font-medium rounded-md hover:bg-fleet-accentHover transition-colors flex items-center shadow-sm">
            
            <PlusCircle className="w-4 h-4 mr-2" />
            Add Driver
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search name or ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-fleet-accent/50 focus:border-fleet-accent dark:text-white transition-colors" />
              
            </div>
            <div className="flex items-center bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 w-full sm:w-auto transition-colors">
              <Filter className="w-4 h-4 text-slate-400 mr-2" />
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="text-sm border-none bg-transparent focus:ring-0 text-slate-700 dark:text-slate-300 font-medium cursor-pointer outline-none">
                
                <option value="all">All Statuses</option>
                <option value="active">Active</option>
                <option value="idle">Idle</option>
                <option value="offline">Offline</option>
              </select>
            </div>
          </div>

          <div className="flex items-center bg-slate-50 dark:bg-slate-950 rounded-lg p-1 border border-slate-200 dark:border-slate-700 self-end sm:self-auto">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-md transition-colors ${viewMode === 'table' ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
              aria-label="Table view">
              
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md transition-colors ${viewMode === 'grid' ? 'bg-white dark:bg-slate-800 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'}`}
              aria-label="Grid view">
              
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content */}
        {viewMode === 'table' ?
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden transition-colors">
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left whitespace-nowrap">
                <thead className="text-xs text-slate-500 dark:text-slate-400 uppercase bg-slate-50/50 dark:bg-slate-800/50 border-b border-slate-100 dark:border-slate-800">
                  <tr>
                    <th className="px-6 py-4 font-medium">Driver</th>
                    <th className="px-6 py-4 font-medium">Contact</th>
                    <th className="px-6 py-4 font-medium">Status</th>
                    <th className="px-6 py-4 font-medium">Current Location</th>
                    <th className="px-6 py-4 font-medium">Last Punch-In</th>
                    <th className="px-6 py-4 font-medium text-right">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredDrivers.map((driver, i) =>
                <motion.tr
                  key={driver.id}
                  initial={{
                    opacity: 0,
                    y: 10
                  }}
                  animate={{
                    opacity: 1,
                    y: 0
                  }}
                  transition={{
                    delay: i * 0.03,
                    duration: 0.2
                  }}
                  onClick={() => navigate(`/drivers/${driver.id}`)}
                  className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors group">
                  
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-3">
                          <img
                        src={driver.photoUrl}
                        alt=""
                        className="w-10 h-10 rounded-full border border-slate-200 dark:border-slate-700 object-cover" />
                      
                          <div>
                            <div className="font-medium text-slate-900 dark:text-white group-hover:text-fleet-accent transition-colors">
                              {driver.name}
                            </div>
                            <div className="text-xs text-slate-500 dark:text-slate-400">
                              {driver.vehicleId}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-slate-600 dark:text-slate-300">
                        {driver.phone}
                      </td>
                      <td className="px-6 py-4">
                        <span
                      className={`px-2.5 py-1 rounded-full text-[10px] uppercase tracking-wider font-bold border ${getStatusColor(driver.status)}`}>
                      
                          {driver.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center text-slate-600 dark:text-slate-300">
                          <MapPin className="w-4 h-4 mr-1.5 text-slate-400" />
                          <span className="truncate max-w-[180px]">
                            {driver.location.lat.toFixed(4)},{' '}
                            {driver.location.lng.toFixed(4)}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4 tabular-nums text-slate-600 dark:text-slate-300">
                        {getLastPunchIn(driver.id)}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button
                      className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      aria-label="Actions">
                      
                          <MoreVertical className="w-4 h-4" />
                        </button>
                      </td>
                    </motion.tr>
                )}
                </tbody>
              </table>
            </div>
          </div> :

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filteredDrivers.map((driver, i) =>
          <motion.div
            key={driver.id}
            initial={{
              opacity: 0,
              scale: 0.95
            }}
            animate={{
              opacity: 1,
              scale: 1
            }}
            transition={{
              delay: i * 0.03,
              duration: 0.2
            }}
            onClick={() => navigate(`/drivers/${driver.id}`)}
            className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm p-5 cursor-pointer hover:border-fleet-accent dark:hover:border-fleet-accent transition-all group">
            
                <div className="flex justify-between items-start mb-4">
                  <img
                src={driver.photoUrl}
                alt=""
                className="w-14 h-14 rounded-full border-2 border-slate-50 dark:border-slate-800 shadow-sm object-cover" />
              
                  <span
                className={`px-2 py-0.5 rounded-full text-[10px] uppercase tracking-wider font-bold border ${getStatusColor(driver.status)}`}>
                
                    {driver.status}
                  </span>
                </div>
                <h3 className="font-bold text-slate-900 dark:text-white text-lg group-hover:text-fleet-accent transition-colors">
                  {driver.name}
                </h3>
                <div className="text-sm text-slate-500 dark:text-slate-400 mb-4">
                  {driver.vehicleId}
                </div>

                <div className="space-y-2 text-sm text-slate-600 dark:text-slate-300 border-t border-slate-100 dark:border-slate-800 pt-4">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Phone</span>
                    <span>{driver.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Punch-In</span>
                    <span className="tabular-nums">
                      {getLastPunchIn(driver.id)}
                    </span>
                  </div>
                </div>
              </motion.div>
          )}
          </div>
        }
      </div>

      <AddDriverModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)} />
      
    </div>);

}
import React from 'react';
import './index.css';
import { render, createRoot } from 'react-dom';
import { App } from './App';
import { ThemeProvider } from './contexts/ThemeContext';
const root = createRoot(document.getElementById('root')!);
root.render(
  <ThemeProvider>
    <App />
  </ThemeProvider>
);
import {
  Driver,
  FaceCapture,
  AttendanceRecord,
  PunchRecord,
  FaceVerificationLog,
  ArrivalTimestamp } from
'../types';

const now = new Date();
const todayStr = now.toISOString().split('T')[0];
const minutesAgo = (mins: number) =>
new Date(now.getTime() - mins * 60000).toISOString();
const hoursAgo = (hours: number) =>
new Date(now.getTime() - hours * 3600000).toISOString();
const timeToday = (hours: number, minutes: number = 0) => {
  const d = new Date();
  d.setHours(hours, minutes, 0, 0);
  return d.toISOString();
};

// Base location: Austin, TX
const AUSTIN_LAT = 30.2672;
const AUSTIN_LNG = -97.7431;

const generateRoute = (
startLat: number,
startLng: number,
points: number,
heading: number) =>
{
  const route = [];
  let currentLat = startLat;
  let currentLng = startLng;
  for (let i = 0; i < points; i++) {
    currentLat += Math.cos(heading * (Math.PI / 180)) * 0.005;
    currentLng += Math.sin(heading * (Math.PI / 180)) * 0.005;
    route.push({
      lat: currentLat,
      lng: currentLng,
      timestamp: minutesAgo(points - i),
      speed: Math.floor(Math.random() * 20) + 30,
      heading
    });
  }
  return route;
};

export const mockDrivers: Driver[] = [
{
  id: 'd1',
  name: 'Marcus Johnson',
  vehicleId: 'TRK-0431',
  status: 'active',
  lastSeen: minutesAgo(1),
  currentSpeed: 45,
  photoUrl: 'https://i.pravatar.cc/150?img=11',
  phone: '+1 (555) 012-3456',
  location: {
    lat: AUSTIN_LAT + 0.02,
    lng: AUSTIN_LNG - 0.01,
    timestamp: minutesAgo(1),
    speed: 45,
    heading: 45
  },
  route: generateRoute(AUSTIN_LAT, AUSTIN_LNG, 20, 45)
},
{
  id: 'd2',
  name: 'Sarah Chen',
  vehicleId: 'TRK-0922',
  status: 'active',
  lastSeen: minutesAgo(0),
  currentSpeed: 38,
  photoUrl: 'https://i.pravatar.cc/150?img=5',
  phone: '+1 (555) 012-3457',
  location: {
    lat: AUSTIN_LAT - 0.05,
    lng: AUSTIN_LNG + 0.03,
    timestamp: minutesAgo(0),
    speed: 38,
    heading: 120
  },
  route: generateRoute(AUSTIN_LAT - 0.1, AUSTIN_LNG, 20, 120)
},
{
  id: 'd3',
  name: 'David Rodriguez',
  vehicleId: 'TRK-1104',
  status: 'idle',
  lastSeen: minutesAgo(15),
  currentSpeed: 0,
  photoUrl: 'https://i.pravatar.cc/150?img=8',
  phone: '+1 (555) 012-3458',
  location: {
    lat: AUSTIN_LAT + 0.08,
    lng: AUSTIN_LNG + 0.05,
    timestamp: minutesAgo(15),
    speed: 0,
    heading: 0
  },
  route: generateRoute(AUSTIN_LAT + 0.05, AUSTIN_LNG + 0.05, 10, 0)
},
{
  id: 'd4',
  name: 'Emily Watson',
  vehicleId: 'TRK-0773',
  status: 'active',
  lastSeen: minutesAgo(2),
  currentSpeed: 32,
  photoUrl: 'https://i.pravatar.cc/150?img=9',
  phone: '+1 (555) 012-3459',
  location: {
    lat: AUSTIN_LAT - 0.02,
    lng: AUSTIN_LNG - 0.06,
    timestamp: minutesAgo(2),
    speed: 32,
    heading: 270
  },
  route: generateRoute(AUSTIN_LAT - 0.02, AUSTIN_LNG - 0.02, 15, 270)
},
{
  id: 'd5',
  name: 'James Wilson',
  vehicleId: 'TRK-0551',
  status: 'offline',
  lastSeen: hoursAgo(4),
  currentSpeed: 0,
  photoUrl: 'https://i.pravatar.cc/150?img=12',
  phone: '+1 (555) 012-3460',
  location: {
    lat: AUSTIN_LAT + 0.1,
    lng: AUSTIN_LNG - 0.08,
    timestamp: hoursAgo(4),
    speed: 0,
    heading: 180
  },
  route: []
},
{
  id: 'd6',
  name: 'Michael Chang',
  vehicleId: 'TRK-0882',
  status: 'offline',
  lastSeen: minutesAgo(5),
  currentSpeed: 0,
  photoUrl: 'https://i.pravatar.cc/150?img=14',
  phone: '+1 (555) 012-3461',
  location: {
    lat: AUSTIN_LAT - 0.07,
    lng: AUSTIN_LNG - 0.04,
    timestamp: minutesAgo(5),
    speed: 0,
    heading: 90
  },
  route: generateRoute(AUSTIN_LAT - 0.07, AUSTIN_LNG - 0.08, 10, 90)
},
{
  id: 'd7',
  name: 'Jessica Taylor',
  vehicleId: 'TRK-0634',
  status: 'active',
  lastSeen: minutesAgo(1),
  currentSpeed: 55,
  photoUrl: 'https://i.pravatar.cc/150?img=20',
  phone: '+1 (555) 012-3462',
  location: {
    lat: AUSTIN_LAT + 0.04,
    lng: AUSTIN_LNG + 0.08,
    timestamp: minutesAgo(1),
    speed: 55,
    heading: 315
  },
  route: generateRoute(AUSTIN_LAT + 0.01, AUSTIN_LNG + 0.05, 25, 315)
},
{
  id: 'd8',
  name: 'Robert Smith',
  vehicleId: 'TRK-0299',
  status: 'active',
  lastSeen: minutesAgo(3),
  currentSpeed: 25,
  photoUrl: 'https://i.pravatar.cc/150?img=33',
  phone: '+1 (555) 012-3463',
  location: {
    lat: AUSTIN_LAT,
    lng: AUSTIN_LNG,
    timestamp: minutesAgo(3),
    speed: 25,
    heading: 180
  },
  route: generateRoute(AUSTIN_LAT + 0.05, AUSTIN_LNG, 15, 180)
}];


export const mockAttendance: AttendanceRecord[] = [
{
  id: 'att1',
  driverId: 'd1',
  date: todayStr,
  punchInTime: timeToday(6, 15),
  punchOutTime: null,
  arrivalTime: timeToday(7, 30),
  totalHours: 4.5,
  status: 'present',
  assignedDestination: 'Distribution Center North',
  arrivalLocation: {
    lat: AUSTIN_LAT + 0.02,
    lng: AUSTIN_LNG - 0.01,
    address: 'Distribution Center North'
  },
  faceVerified: true
},
{
  id: 'att2',
  driverId: 'd2',
  date: todayStr,
  punchInTime: timeToday(6, 45),
  punchOutTime: null,
  arrivalTime: timeToday(8, 15),
  totalHours: 4.0,
  status: 'present',
  assignedDestination: 'Retail Hub A',
  arrivalLocation: {
    lat: AUSTIN_LAT - 0.05,
    lng: AUSTIN_LNG + 0.03,
    address: 'Retail Hub A'
  },
  faceVerified: true
},
{
  id: 'att3',
  driverId: 'd3',
  date: todayStr,
  punchInTime: timeToday(8, 30),
  punchOutTime: null,
  arrivalTime: null,
  totalHours: 2.25,
  status: 'late',
  assignedDestination: 'Warehouse South',
  arrivalLocation: null,
  faceVerified: true
},
{
  id: 'att4',
  driverId: 'd4',
  date: todayStr,
  punchInTime: timeToday(7, 0),
  punchOutTime: null,
  arrivalTime: timeToday(8, 45),
  totalHours: 3.75,
  status: 'on-route',
  assignedDestination: '290 Toll Road Depot',
  arrivalLocation: null,
  faceVerified: true
},
{
  id: 'att5',
  driverId: 'd5',
  date: todayStr,
  punchInTime: timeToday(5, 30),
  punchOutTime: timeToday(14, 0),
  arrivalTime: timeToday(6, 45),
  totalHours: 8.5,
  status: 'off-duty',
  assignedDestination: 'HQ',
  arrivalLocation: {
    lat: AUSTIN_LAT + 0.1,
    lng: AUSTIN_LNG - 0.08,
    address: 'HQ'
  },
  faceVerified: true
},
{
  id: 'att6',
  driverId: 'd6',
  date: todayStr,
  punchInTime: null,
  punchOutTime: null,
  arrivalTime: null,
  totalHours: 0,
  status: 'absent',
  assignedDestination: 'Distribution Center East',
  arrivalLocation: null,
  faceVerified: false
},
{
  id: 'att7',
  driverId: 'd7',
  date: todayStr,
  punchInTime: timeToday(6, 0),
  punchOutTime: null,
  arrivalTime: timeToday(7, 15),
  totalHours: 4.75,
  status: 'present',
  assignedDestination: 'Retail Hub B',
  arrivalLocation: {
    lat: AUSTIN_LAT + 0.04,
    lng: AUSTIN_LNG + 0.08,
    address: 'Retail Hub B'
  },
  faceVerified: true
},
{
  id: 'att8',
  driverId: 'd8',
  date: todayStr,
  punchInTime: timeToday(7, 15),
  punchOutTime: null,
  arrivalTime: timeToday(9, 0),
  totalHours: 3.5,
  status: 'present',
  assignedDestination: 'Warehouse North',
  arrivalLocation: {
    lat: AUSTIN_LAT,
    lng: AUSTIN_LNG,
    address: 'Warehouse North'
  },
  faceVerified: false
} // Verification failed
];

export const mockPunchRecords: PunchRecord[] = [
{
  id: 'p1',
  driverId: 'd1',
  type: 'punch-in',
  timestamp: timeToday(6, 15),
  location: {
    lat: AUSTIN_LAT + 0.1,
    lng: AUSTIN_LNG - 0.1,
    address: 'Driver Home Base'
  },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=11',
  verificationStatus: 'verified',
  confidenceScore: 98
},
{
  id: 'p2',
  driverId: 'd1',
  type: 'arrival',
  timestamp: timeToday(7, 30),
  location: {
    lat: AUSTIN_LAT + 0.02,
    lng: AUSTIN_LNG - 0.01,
    address: 'Distribution Center North'
  },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=11',
  verificationStatus: 'verified',
  confidenceScore: 95
},
{
  id: 'p3',
  driverId: 'd2',
  type: 'punch-in',
  timestamp: timeToday(6, 45),
  location: {
    lat: AUSTIN_LAT - 0.1,
    lng: AUSTIN_LNG + 0.1,
    address: 'Driver Home Base'
  },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=5',
  verificationStatus: 'verified',
  confidenceScore: 99
},
{
  id: 'p4',
  driverId: 'd3',
  type: 'punch-in',
  timestamp: timeToday(8, 30),
  location: {
    lat: AUSTIN_LAT + 0.05,
    lng: AUSTIN_LNG + 0.05,
    address: 'Driver Home Base'
  },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=8',
  verificationStatus: 'verified',
  confidenceScore: 92,
  notes: 'Late start due to traffic'
},
{
  id: 'p5',
  driverId: 'd5',
  type: 'punch-in',
  timestamp: timeToday(5, 30),
  location: { lat: AUSTIN_LAT + 0.1, lng: AUSTIN_LNG - 0.08, address: 'HQ' },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=12',
  verificationStatus: 'verified',
  confidenceScore: 97
},
{
  id: 'p6',
  driverId: 'd5',
  type: 'punch-out',
  timestamp: timeToday(14, 0),
  location: { lat: AUSTIN_LAT + 0.1, lng: AUSTIN_LNG - 0.08, address: 'HQ' },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=12',
  verificationStatus: 'verified',
  confidenceScore: 96
},
{
  id: 'p7',
  driverId: 'd8',
  type: 'punch-in',
  timestamp: timeToday(7, 15),
  location: { lat: AUSTIN_LAT, lng: AUSTIN_LNG, address: 'Driver Home Base' },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=33',
  verificationStatus: 'failed',
  confidenceScore: 45,
  notes: 'Poor lighting, face not recognized'
},
{
  id: 'p8',
  driverId: 'd8',
  type: 'punch-in',
  timestamp: timeToday(7, 16),
  location: { lat: AUSTIN_LAT, lng: AUSTIN_LNG, address: 'Driver Home Base' },
  facePhotoUrl: 'https://i.pravatar.cc/150?img=33',
  verificationStatus: 'pending',
  confidenceScore: 75,
  notes: 'Manual review required'
}];


export const mockFaceVerificationLogs: FaceVerificationLog[] = [
{
  id: 'fv1',
  driverId: 'd1',
  timestamp: timeToday(6, 15),
  capturedPhotoUrl: 'https://i.pravatar.cc/150?img=11',
  referencePhotoUrl: 'https://i.pravatar.cc/150?img=11',
  status: 'verified',
  confidenceScore: 98,
  location: {
    lat: AUSTIN_LAT + 0.1,
    lng: AUSTIN_LNG - 0.1,
    address: 'Driver Home Base'
  },
  punchType: 'punch-in'
},
{
  id: 'fv2',
  driverId: 'd2',
  timestamp: timeToday(6, 45),
  capturedPhotoUrl: 'https://i.pravatar.cc/150?img=5',
  referencePhotoUrl: 'https://i.pravatar.cc/150?img=5',
  status: 'verified',
  confidenceScore: 99,
  location: {
    lat: AUSTIN_LAT - 0.1,
    lng: AUSTIN_LNG + 0.1,
    address: 'Driver Home Base'
  },
  punchType: 'punch-in'
},
{
  id: 'fv3',
  driverId: 'd8',
  timestamp: timeToday(7, 15),
  capturedPhotoUrl: 'https://i.pravatar.cc/150?img=33',
  referencePhotoUrl: 'https://i.pravatar.cc/150?img=33',
  status: 'failed',
  confidenceScore: 45,
  location: { lat: AUSTIN_LAT, lng: AUSTIN_LNG, address: 'Driver Home Base' },
  punchType: 'punch-in'
},
{
  id: 'fv4',
  driverId: 'd8',
  timestamp: timeToday(7, 16),
  capturedPhotoUrl: 'https://i.pravatar.cc/150?img=33',
  referencePhotoUrl: 'https://i.pravatar.cc/150?img=33',
  status: 'pending',
  confidenceScore: 75,
  location: { lat: AUSTIN_LAT, lng: AUSTIN_LNG, address: 'Driver Home Base' },
  punchType: 'punch-in'
},
{
  id: 'fv5',
  driverId: 'd1',
  timestamp: timeToday(7, 30),
  capturedPhotoUrl: 'https://i.pravatar.cc/150?img=11',
  referencePhotoUrl: 'https://i.pravatar.cc/150?img=11',
  status: 'verified',
  confidenceScore: 95,
  location: {
    lat: AUSTIN_LAT + 0.02,
    lng: AUSTIN_LNG - 0.01,
    address: 'Distribution Center North'
  },
  punchType: 'arrival'
}];


export const mockArrivalTimestamps: ArrivalTimestamp[] = [
{
  id: 'at1',
  driverId: 'd1',
  destination: 'Distribution Center North',
  scheduledTime: timeToday(7, 15),
  actualArrivalTime: timeToday(7, 30),
  location: {
    lat: AUSTIN_LAT + 0.02,
    lng: AUSTIN_LNG - 0.01,
    address: 'Distribution Center North'
  },
  status: 'late',
  delay: 15
},
{
  id: 'at2',
  driverId: 'd2',
  destination: 'Retail Hub A',
  scheduledTime: timeToday(8, 30),
  actualArrivalTime: timeToday(8, 15),
  location: {
    lat: AUSTIN_LAT - 0.05,
    lng: AUSTIN_LNG + 0.03,
    address: 'Retail Hub A'
  },
  status: 'on-time'
},
{
  id: 'at3',
  driverId: 'd4',
  destination: '290 Toll Road Depot',
  scheduledTime: timeToday(9, 0),
  actualArrivalTime: null,
  location: {
    lat: AUSTIN_LAT - 0.02,
    lng: AUSTIN_LNG - 0.06,
    address: '290 Toll Road Depot'
  },
  status: 'pending'
},
{
  id: 'at4',
  driverId: 'd6',
  destination: 'Distribution Center East',
  scheduledTime: timeToday(7, 0),
  actualArrivalTime: null,
  location: {
    lat: AUSTIN_LAT - 0.07,
    lng: AUSTIN_LNG - 0.04,
    address: 'Distribution Center East'
  },
  status: 'missed'
}];


export const mockFaceCaptures: FaceCapture[] = []; // Kept for type compatibility if needed, but largely replaced by FaceVerificationLog
export type DriverStatus = 'active' | 'idle' | 'alert' | 'offline';

export type AttendanceStatus =
'present' |
'late' |
'absent' |
'on-route' |
'off-duty';
export type VerificationStatus = 'verified' | 'pending' | 'failed';
export type PunchType = 'punch-in' | 'punch-out' | 'arrival';

export interface GPSPing {
  lat: number;
  lng: number;
  timestamp: string;
  speed: number; // mph
  heading: number; // degrees
}

export interface Driver {
  id: string;
  name: string;
  vehicleId: string;
  status: DriverStatus;
  lastSeen: string;
  currentSpeed: number;
  photoUrl: string;
  phone: string;
  location: GPSPing;
  route: GPSPing[]; // recent route for the detail map
}

export interface FaceCapture {
  id: string;
  driverId: string;
  tripId: string;
  photoUrl: string;
  timestamp: string;
  location: {lat: number;lng: number;address: string;};
  verified: boolean;
}

export interface AttendanceRecord {
  id: string;
  driverId: string;
  date: string; // YYYY-MM-DD
  punchInTime: string | null; // ISO
  punchOutTime: string | null; // ISO
  arrivalTime: string | null; // ISO
  totalHours: number;
  status: AttendanceStatus;
  assignedDestination: string;
  arrivalLocation: {lat: number;lng: number;address: string;} | null;
  faceVerified: boolean;
}

export interface PunchRecord {
  id: string;
  driverId: string;
  type: PunchType;
  timestamp: string; // ISO
  location: {lat: number;lng: number;address: string;};
  facePhotoUrl: string;
  verificationStatus: VerificationStatus;
  confidenceScore: number; // 0-100
  notes?: string;
}

export interface FaceVerificationLog {
  id: string;
  driverId: string;
  timestamp: string; // ISO
  capturedPhotoUrl: string;
  referencePhotoUrl: string;
  status: VerificationStatus;
  confidenceScore: number; // 0-100
  location: {lat: number;lng: number;address: string;};
  punchType: PunchType;
}

export interface ArrivalTimestamp {
  id: string;
  driverId: string;
  destination: string;
  scheduledTime: string; // ISO
  actualArrivalTime: string | null; // ISO
  location: {lat: number;lng: number;address: string;};
  status: 'on-time' | 'late' | 'pending' | 'missed';
  delay?: number; // minutes
}
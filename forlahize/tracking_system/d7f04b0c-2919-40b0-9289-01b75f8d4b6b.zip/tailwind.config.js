
/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      colors: {
        fleet: {
          bg: '#F7F8FA',
          sidebar: '#0f172a', // slate-900
          sidebarHover: '#1e293b', // slate-800
          accent: '#f59e0b', // amber-500
          accentHover: '#d97706', // amber-600
          active: '#10b981', // emerald-500
          idle: '#f59e0b', // amber-500
          alert: '#ef4444', // red-500
          offline: '#94a3b8', // slate-400
        }
      }
    },
  },
  plugins: [],
}
